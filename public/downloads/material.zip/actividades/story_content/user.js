function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5q35o0YCywf":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

